/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package view;

/**
 *
 * @author User
 */
public enum Telas {
    SOBRE,
    NOVO_PRODUTO,
    ALTERAR_PRODUTO,
    EXCLUIR_PRODUTO,
    GERENCIA_PRODUTO
}
